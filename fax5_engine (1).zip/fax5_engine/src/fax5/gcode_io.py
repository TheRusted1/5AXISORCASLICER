"""
Minimal G-code I/O for the hybrid pipeline:

  OrcaSlicer (unmodified, AGPLv3, used only as an external CLI tool)
        --> ordinary 3-axis G-code (this module's `parse`)
        --> nonplanar region detection + IK retargeting (separate, proprietary)
        --> 5-axis G-code with A/B words added (this module's `write`)

Deliberately not a general-purpose G-code library -- just enough structure
(position tracking, line classification) for the nonplanar pipeline to find
"this is the top surface of layer N" and rewrite those specific moves.
"""

from dataclasses import dataclass, replace
from typing import List, Optional
import re

_MOVE_RE = re.compile(r"^[Gg](0|1)\b")
_COORD_RE = re.compile(r"([XYZEFABxyzefab])(-?\d*\.?\d+)")


@dataclass
class Move:
    raw: str  # original line, kept so untouched moves round-trip byte-for-byte
    is_move: bool
    x: Optional[float] = None
    y: Optional[float] = None
    z: Optional[float] = None
    e: Optional[float] = None
    f: Optional[float] = None
    a: Optional[float] = None  # only ever set after 5-axis retargeting
    b: Optional[float] = None
    comment: Optional[float] = None


def parse(gcode_text: str) -> List[Move]:
    """Parse standard G-code into a list of Move records. Absolute
    positioning (G90) is assumed, matching OrcaSlicer's default output --
    this does not currently track G91 relative mode; if your profile uses
    relative XYZ, normalize that on the OrcaSlicer side first."""
    moves = []
    for line in gcode_text.splitlines():
        stripped = line.split(";", 1)[0].strip()
        if not stripped or not _MOVE_RE.match(stripped):
            moves.append(Move(raw=line, is_move=False))
            continue
        fields = {k.upper(): float(v) for k, v in _COORD_RE.findall(stripped)}
        moves.append(
            Move(
                raw=line,
                is_move=True,
                x=fields.get("X"),
                y=fields.get("Y"),
                z=fields.get("Z"),
                e=fields.get("E"),
                f=fields.get("F"),
            )
        )
    return moves


def carry_forward_positions(moves: List[Move]) -> List[Move]:
    """Fill in X/Y/Z for moves that omit an axis (G-code only states axes
    that change). After this pass every `is_move` Move has a concrete x,y,z
    -- required before you can ask 'what point on the part is this move
    actually at' for nonplanar retargeting."""
    out = []
    cx = cy = cz = 0.0
    for m in moves:
        if m.is_move:
            cx = m.x if m.x is not None else cx
            cy = m.y if m.y is not None else cy
            cz = m.z if m.z is not None else cz
            out.append(replace(m, x=cx, y=cy, z=cz))
        else:
            out.append(m)
    return out


def write(moves: List[Move], a_word: str = "A", b_word: str = "B") -> str:
    """Emit G-code. Moves with a/b set get the rotary words appended;
    everything else (including all non-move lines) is passed through
    unchanged so OrcaSlicer's start/end gcode, temperature commands etc.
    survive untouched."""
    lines = []
    for m in moves:
        if not m.is_move or (m.a is None and m.b is None):
            lines.append(m.raw)
            continue
        parts = [m.raw.split(";", 1)[0].rstrip()]
        if m.a is not None:
            parts.append(f"{a_word}{m.a:.4f}")
        if m.b is not None:
            parts.append(f"{b_word}{m.b:.4f}")
        comment = ""
        if ";" in m.raw:
            comment = " ;" + m.raw.split(";", 1)[1]
        lines.append(" ".join(parts) + comment)
    return "\n".join(lines) + "\n"
