"""
Forward and inverse kinematics for a rotating-bed / tilting-head 5-axis FDM
printer. See machine_config.py for what each geometry parameter means and how
to measure it.

CONVENTION -- read this before touching any sign:
    `tool_axis` always means the unit vector pointing from the toolhead body,
    through the nozzle tip, in the direction material is deposited -- i.e.
    the direction the nozzle is "aimed." At B = 0 this is MachineConfig.
    nominal_tool_axis_local, normally (0, 0, -1) (aimed straight down).

    If you're driving this from a surface normal `n` (pointing away from the
    printed surface, into open air), the nozzle approaches from the outside
    aimed inward, so pass `target_axis_part = -n`.

Two frames:
    "world" / "gantry" frame -- static, does not rotate with the bed.
    "part" / "bed" frame      -- rotates with the bed by the A axis; this is
                                  the frame your mesh/STL geometry lives in.

SAFETY: before trusting any G-code this produces, verify sign conventions on
the real machine at LOW SPEED with the nozzle backed well away from the bed:
jog A and B a small known amount and confirm forward_kinematics() predicts
the resulting nozzle pose. A flipped sign here is a nozzle-into-bed crash at
full toolpath speed, not a cosmetic bug.
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from .machine_config import MachineConfig, _unit


def _rotation_matrix(axis: np.ndarray, angle_rad: float) -> np.ndarray:
    """Rodrigues' rotation formula. axis must be a unit vector."""
    a = _unit(axis)
    c, s = np.cos(angle_rad), np.sin(angle_rad)
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return np.eye(3) + s * K + (1 - c) * (K @ K)


def _z_rotation(angle_rad: float) -> np.ndarray:
    return _rotation_matrix(np.array([0.0, 0.0, 1.0]), angle_rad)


@dataclass
class Pose:
    """Nozzle pose expressed in both frames -- whichever you need is there."""
    nozzle_pos_world: np.ndarray
    tool_axis_world: np.ndarray
    nozzle_pos_part: np.ndarray
    tool_axis_part: np.ndarray


def forward_kinematics(
    x: float, y: float, z: float, a_deg: float, b_deg: float, cfg: MachineConfig
) -> Pose:
    """Joint values -> where the nozzle actually is, in both frames."""
    head_ref_world = np.array([x, y, z])

    pivot_world = head_ref_world + cfg.tilt_pivot_offset
    R_b = _rotation_matrix(cfg.tilt_axis_local, np.radians(b_deg))
    nozzle_pos_world = pivot_world + R_b @ cfg.nozzle_offset_from_pivot
    tool_axis_world = R_b @ cfg.nominal_tool_axis_local

    bed_center_world = np.array([cfg.bed_center_xy[0], cfg.bed_center_xy[1], 0.0])
    R_a = _z_rotation(np.radians(a_deg))
    nozzle_pos_part = R_a.T @ (nozzle_pos_world - bed_center_world)
    tool_axis_part = R_a.T @ tool_axis_world

    return Pose(nozzle_pos_world, tool_axis_world, nozzle_pos_part, tool_axis_part)


class UnreachableOrientationError(ValueError):
    """Raised when no value of A can bring the requested tool axis onto the
    cone the B axis can sweep -- i.e. the geometry genuinely cannot point the
    nozzle that way, not a numerical issue."""


def inverse_kinematics(
    target_point_part: np.ndarray,
    target_axis_part: np.ndarray,
    cfg: MachineConfig,
    prefer_a_near: Optional[float] = None,
) -> List[Tuple[float, float, float, float, float]]:
    """
    Solve for (x, y, z, a_deg, b_deg) that places the nozzle at
    `target_point_part` (in the rotating part/bed frame) aimed along
    `target_axis_part` (unit vector, same frame, same convention as
    forward_kinematics' tool_axis_part).

    Returns a list of 0, 1, or 2 valid solutions (A has two branches, similar
    in spirit to elbow-up/elbow-down in robot arms -- which one is
    "better" depends on B-axis limits and on continuity with the previous
    point in your toolpath, which is a path-planning decision, not a
    kinematics one. That's why this returns candidates rather than picking
    for you, aside from the `prefer_a_near` convenience below.)

    Raises UnreachableOrientationError if the target orientation is outside
    what the B axis can reach for ANY value of A.
    """
    p = np.asarray(target_point_part, dtype=float)
    n = _unit(np.asarray(target_axis_part, dtype=float))
    t = cfg.tilt_axis_local
    n0 = cfg.nominal_tool_axis_local

    c = float(np.dot(n0, t))  # cosine of the cone half-angle B sweeps n0 through

    nx, ny, nz = n
    tx, ty, tz = t
    t_xy_sq = tx * tx + ty * ty
    n_xy_sq = nx * nx + ny * ny

    if t_xy_sq < 1e-12:
        # True machine degeneracy: tilt axis itself is vertical, so B never
        # tilts the nozzle off-vertical at all. Not fixable by choice of A.
        raise UnreachableOrientationError(
            "Degenerate geometry: tilt_axis_local has no XY component -- "
            "the B axis cannot tilt the nozzle off vertical. Check MachineConfig."
        )

    if n_xy_sq < 1e-12:
        # target_axis_part is exactly vertical (straight up/down in the part
        # frame). Rotating about world Z (the A axis) does not move a
        # vertical vector at all, so A has no effect on reachability here --
        # it's either reachable for every A, or for none.
        rhs_vertical = c - tz * nz
        if abs(rhs_vertical) > 1e-6:
            raise UnreachableOrientationError(
                f"target_axis_part {n} is vertical and not reachable by this "
                f"B axis for ANY value of A (this machine's tilt geometry "
                f"can't point straight {'up' if nz > 0 else 'down'} here)."
            )
        a_rad_candidates = [np.radians(prefer_a_near if prefer_a_near is not None else 0.0)]
    else:
        P = tx * nx + ty * ny
        Q = ty * nx - tx * ny
        rhs = c - tz * nz
        R = np.hypot(P, Q)
        ratio = rhs / R
        if abs(ratio) > 1.0 + 1e-9:
            raise UnreachableOrientationError(
                f"target_axis_part {n} is not reachable by this B axis for any "
                f"value of A (ratio={ratio:.4f}, must be in [-1, 1])."
            )
        ratio = float(np.clip(ratio, -1.0, 1.0))
        phi = np.arctan2(Q, P)
        delta = np.arccos(ratio)
        a_rad_candidates = [phi + delta, phi - delta]

    solutions = []
    for a_rad in a_rad_candidates:
        R_a = _z_rotation(a_rad)
        target_axis_world = R_a @ n

        # Solve B: angle that rotates n0 about t into target_axis_world.
        n0_perp = n0 - np.dot(n0, t) * t
        v_perp = target_axis_world - np.dot(target_axis_world, t) * t
        n0_perp_norm = np.linalg.norm(n0_perp)
        v_perp_norm = np.linalg.norm(v_perp)
        if n0_perp_norm < 1e-9 or v_perp_norm < 1e-9:
            # nominal tool axis is parallel to tilt axis -- B has no effect.
            # Shouldn't happen for a real tilting head (B would be useless),
            # flag rather than silently returning a meaningless B.
            raise UnreachableOrientationError(
                "nominal_tool_axis_local is parallel to tilt_axis_local -- "
                "the B axis cannot orient the tool at all. Check MachineConfig."
            )
        cosB = np.dot(n0_perp, v_perp) / (n0_perp_norm * v_perp_norm)
        sinB = np.dot(np.cross(n0_perp, v_perp), t) / (n0_perp_norm * v_perp_norm)
        b_rad = np.arctan2(sinB, cosB)
        b_deg = np.degrees(b_rad)
        a_deg = np.degrees(a_rad)

        R_b = _rotation_matrix(t, b_rad)
        pivot_world = R_a @ p + np.array(
            [cfg.bed_center_xy[0], cfg.bed_center_xy[1], 0.0]
        ) - R_b @ cfg.nozzle_offset_from_pivot
        head_ref_world = pivot_world - cfg.tilt_pivot_offset

        solutions.append(
            (
                float(head_ref_world[0]),
                float(head_ref_world[1]),
                float(head_ref_world[2]),
                float(a_deg),
                float(b_deg),
            )
        )

    # De-duplicate (the two branches coincide exactly at the cone boundary)
    if len(solutions) == 2 and np.allclose(solutions[0], solutions[1], atol=1e-6):
        solutions = solutions[:1]

    # Filter to B-axis limits. A solution outside the real mechanical range
    # is not "less good," it's impossible -- never hand it back silently.
    lo, hi = cfg.b_axis_limits_deg
    in_limits = [s for s in solutions if min(lo, hi) - 1e-6 <= s[4] <= max(lo, hi) + 1e-6]
    if not in_limits:
        raise UnreachableOrientationError(
            f"target_axis_part {n} requires B outside the mechanical limit "
            f"{cfg.b_axis_limits_deg} for every candidate A "
            f"(candidates: {[round(s[4], 2) for s in solutions]})."
        )
    candidates = in_limits

    if prefer_a_near is not None and len(candidates) > 1:
        candidates = sorted(
            candidates, key=lambda s: _angle_diff_deg(s[3], prefer_a_near)
        )

    return candidates


def _angle_diff_deg(a: float, b: float) -> float:
    d = (a - b + 180.0) % 360.0 - 180.0
    return abs(d)
