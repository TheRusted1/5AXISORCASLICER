"""
Machine geometry for a "rotating bed + tilting head" 5-axis FDM printer.

Axis convention (pick names that match your firmware; A/B are placeholders):
  X, Y, Z  - linear gantry axes, as on a normal 3-axis printer.
  A        - bed rotation about a VERTICAL axis through the bed center.
             Continuous (no travel limit), analogous to a CNC rotary table.
  B        - toolhead tilt about a HORIZONTAL axis fixed to the gantry/carriage.
             Limited range (e.g. 0 to -90 deg).

Everything downstream (kinematics, collision checking, the nonplanar toolpath
generator) is driven entirely by the numbers in MachineConfig. Get these right
and the rest of the math below is correct; get them wrong and the printer will
calculate a perfectly self-consistent path to crash the nozzle into the bed.

HOW TO MEASURE EACH FIELD (do this on the real machine, not from CAD alone --
real assemblies have slop/offset that matters at sub-mm precision):

  tilt_pivot_offset
      Vector from the point your firmware considers "the carriage XYZ
      position" (wherever your motion system's coordinate origin for the
      toolhead effectively is) to the physical tilt hinge axis, measured with
      B = 0 (head hanging straight down) and in the gantry's own un-tilted
      frame (x = gantry left/right, y = gantry front/back, z = up).
      Practically: this is "how far is the hinge from wherever X/Y/Z=0
      reports the toolhead to be," in mm, along each axis.

  tilt_axis_local
      Unit vector describing which way the hinge axis points when B = 0.
      E.g. (1, 0, 0) if the head rocks forward/back (hinge runs left-right),
      or (0, 1, 0) if it rocks side to side (hinge runs front-back).

  nozzle_offset_from_pivot
      Vector from the tilt hinge axis to the nozzle TIP, measured at B = 0.
      Mostly (0, 0, -L) where L is the hinge-to-nozzle-tip distance in mm.
      This number alone sets your maximum reachable tilt before the nozzle
      whacks something, so measure it carefully (calipers, not eyeballing).

  bed_center_xy
      (x, y) location of the bed's rotation axis in gantry/world coordinates,
      i.e. where the bed center sits when the gantry is at its home position.

  b_axis_limits_deg
      (min, max) mechanical tilt range, in degrees, B = 0 being "nozzle
      points straight down." Add real margin for the hotend/fan shroud
      silhouette, not just the lead screws/frame -- the first thing to crash
      is usually a fan duct or wire chain, not the structural part.

  z_is_relative
      True for this whole model: "z" passed into the functions below is the
      RELATIVE vertical offset between the carriage reference point and the
      bed. It doesn't matter whether your machine actually realizes Z by
      lifting the bed (Voron Trident style, on 3 synced leadscrews) or moving
      the gantry vertically -- the kinematics below only cares about the
      relative pose. Map this relative Z to whichever physical axis actually
      moves in your motion-system/Klipper integration layer.
"""

from dataclasses import dataclass, field
from typing import Tuple
import numpy as np


@dataclass
class MachineConfig:
    # --- TODO: replace every value below with a measurement off the real machine ---
    tilt_pivot_offset: np.ndarray = field(
        default_factory=lambda: np.array([0.0, 0.0, 0.0])
    )
    tilt_axis_local: np.ndarray = field(
        default_factory=lambda: np.array([1.0, 0.0, 0.0])
    )
    nozzle_offset_from_pivot: np.ndarray = field(
        default_factory=lambda: np.array([0.0, 0.0, -50.0])
    )
    bed_center_xy: Tuple[float, float] = (0.0, 0.0)
    b_axis_limits_deg: Tuple[float, float] = (-90.0, 0.0)
    a_axis_continuous: bool = True

    # Direction the nozzle points when B = 0. This is a convention, not a
    # measurement -- "straight down" -- leave it alone unless your B=0 pose
    # is defined differently.
    nominal_tool_axis_local: np.ndarray = field(
        default_factory=lambda: np.array([0.0, 0.0, -1.0])
    )

    def __post_init__(self):
        self.tilt_pivot_offset = np.asarray(self.tilt_pivot_offset, dtype=float)
        self.nozzle_offset_from_pivot = np.asarray(
            self.nozzle_offset_from_pivot, dtype=float
        )
        self.nominal_tool_axis_local = _unit(
            np.asarray(self.nominal_tool_axis_local, dtype=float)
        )
        self.tilt_axis_local = _unit(np.asarray(self.tilt_axis_local, dtype=float))

    @classmethod
    def placeholder(cls) -> "MachineConfig":
        """Numbers good enough to exercise the math, NOT a real machine.
        Used only by the test suite until real geometry is measured."""
        return cls()

    @classmethod
    def voron_trident_250_test(cls) -> "MachineConfig":
        """
        Rough numbers for a Voron Trident 250 frame, for smoke-testing the
        pipeline only -- NOT measured off the real machine, do not print
        with these. Replace every value here once you've actually measured
        the hardware (see module docstring above for how).

        Assumptions baked in, flagged so you remember to check them:
          - bed_center_xy = (125, 125): Trident 250 bed is ~250x250mm,
            origin assumed at the front-left corner (standard Klipper
            convention) so the rotation axis sits at the geometric center.
            If your bed's rotation axis isn't centered on the build plate,
            this is wrong -- measure where the slip ring's axis actually is.
          - nozzle_offset_from_pivot = (0, 40, 0): per your note that the
            offset is mostly Y. Worth double-checking this physically --
            normally you'd expect at least some -Z component too, since the
            nozzle has to hang below the pivot to reach the bed at all. If
            your hinge is mounted such that the pivot axis is already at
            nozzle height and only displaced sideways, Y-only is right; if
            not, you're missing the Z term and IK will silently produce a
            self-consistent but wrong answer.
          - tilt_pivot_offset = (0, 0, 30): guessed mount-point-to-hinge
            distance, not measured.
          - b_axis_limits_deg = (-45, 0): guessed conservative range.
        """
        return cls(
            tilt_pivot_offset=np.array([0.0, 0.0, 30.0]),
            tilt_axis_local=np.array([1.0, 0.0, 0.0]),
            nozzle_offset_from_pivot=np.array([0.0, 40.0, 0.0]),
            bed_center_xy=(125.0, 125.0),
            b_axis_limits_deg=(-45.0, 0.0),
        )


def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    if n < 1e-12:
        raise ValueError(f"Zero-length vector where a direction was expected: {v}")
    return v / n
