"""
End-to-end pipeline:

    1. orcaslicer_slice()   -- shell out to the unmodified OrcaSlicer binary,
                               headless, to produce ordinary 3-axis G-code.
                               OrcaSlicer is never patched or linked against;
                               this is the AGPL boundary -- treating it as an
                               external program invoked via the command line
                               and exchanging files is the standard, accepted
                               way to use AGPL/GPL tools from closed-source
                               software (see project README for the caveat).

    2. classify_moves()     -- use OrcaSlicer's own ";TYPE:" G-code comments
                               to find which moves are top/bottom solid
                               infill and which are external perimeter, with
                               no mesh analysis needed for this step.

    3. retarget_to_surface()-- for the moves worth treating as nonplanar,
                               ray-cast against the ORIGINAL mesh (not the
                               sliced layers) to find the true surface point
                               + normal under each (x, y), then solve 5-axis
                               IK for that point so the nozzle actually lands
                               on the surface instead of the flat layer Z.

    4. write 5-axis G-code with A/B words added only on the retargeted moves.

v1 scope: top/bottom surfaces only (the more tractable nonplanar problem --
see conversation history for why). Outer-wall continuous nonplanar following
is a stub below (`retarget_outer_wall`) with the algorithmic approach noted,
deliberately not implemented yet -- that one needs real collision modeling
against the nozzle/fan-shroud silhouette before it's safe to run, which in
turn needs your actual machine geometry.
"""

from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
from typing import List, Optional

import numpy as np
import trimesh

from . import gcode_io
from .gcode_io import Move
from .kinematics import MachineConfig, inverse_kinematics, UnreachableOrientationError

_TYPE_RE = re.compile(r";\s*TYPE:\s*(.+)")

TOP_BOTTOM_TYPES = {"Top solid infill", "Bottom solid infill", "Solid infill"}


def orcaslicer_slice(
    project_3mf: Path,
    output_gcode: Path,
    orcaslicer_binary: str = "orca-slicer",
) -> Path:
    """
    Headless slice via the OrcaSlicer CLI. Run `orca-slicer --help` on your
    actual install first -- the active CLI flag set has shifted between
    versions (several flags exist in the source but are compiled out in
    some builds), so don't trust this exact invocation blindly. As of the
    version checked while building this pipeline, `--slice <plate>` is the
    confirmed-active flag; output path control is more version-dependent --
    you may need to let it write next to the input and move the file
    yourself, which is what this function falls back to.
    """
    cmd = [orcaslicer_binary, "--slice", "0", str(project_3mf)]
    subprocess.run(cmd, check=True)
    default_output = project_3mf.with_suffix(".gcode")
    if default_output != output_gcode and default_output.exists():
        default_output.replace(output_gcode)
    return output_gcode


@dataclass
class ClassifiedMove:
    move: Move
    region_type: Optional[str]  # value from the last seen ";TYPE:" comment


def classify_moves(moves: List[Move]) -> List[ClassifiedMove]:
    out = []
    current_type: Optional[str] = None
    for m in moves:
        if not m.is_move:
            match = _TYPE_RE.search(m.raw)
            if match:
                current_type = match.group(1).strip()
        out.append(ClassifiedMove(move=m, region_type=current_type))
    return out


def surface_point_and_normal(
    mesh: trimesh.Trimesh, x: float, y: float
) -> Optional[tuple]:
    """Ray-cast straight down through (x, y) and return the (point, normal)
    of the HIGHEST surface hit -- i.e. what a top-surface toolpath at this
    (x, y) should actually be conforming to. Returns None if the ray misses
    the mesh entirely (shouldn't happen for points OrcaSlicer already
    decided belong to a top surface, but don't assume)."""
    origin = np.array([[x, y, mesh.bounds[1][2] + 10.0]])
    direction = np.array([[0.0, 0.0, -1.0]])
    locations, _, index_tri = mesh.ray.intersects_location(origin, direction)
    if len(locations) == 0:
        return None
    top_idx = int(np.argmax(locations[:, 2]))
    point = locations[top_idx]
    normal = mesh.face_normals[index_tri[top_idx]]
    return point, normal / np.linalg.norm(normal)


def retarget_top_bottom(
    classified: List[ClassifiedMove],
    mesh: trimesh.Trimesh,
    cfg: MachineConfig,
) -> List[Move]:
    """Rewrite top/bottom-surface moves to follow the real mesh surface
    instead of the flat layer Z, producing (x, y, z, a, b) for each one.
    Moves OrcaSlicer didn't tag as top/bottom pass through untouched."""
    out: List[Move] = []
    prev_a = 0.0
    for cm in classified:
        m = cm.move
        if not m.is_move or cm.region_type not in TOP_BOTTOM_TYPES:
            out.append(m)
            continue

        hit = surface_point_and_normal(mesh, m.x, m.y)
        if hit is None:
            out.append(m)  # leave this one planar rather than guess
            continue
        point, normal = hit

        target_axis = -normal  # nozzle approaches from outside, aimed inward
        try:
            solutions = inverse_kinematics(point, target_axis, cfg, prefer_a_near=prev_a)
        except UnreachableOrientationError:
            out.append(m)  # local slope outside machine reach -- leave planar
            continue

        x, y, z, a_deg, b_deg = solutions[0]
        prev_a = a_deg
        out.append(
            Move(raw=m.raw, is_move=True, x=x, y=y, z=z, e=m.e, f=m.f, a=a_deg, b=b_deg)
        )
    return out


def retarget_outer_wall(classified, mesh, cfg):
    """NOT IMPLEMENTED YET.

    Planned approach (write this once the IK above is verified on real
    hardware -- this is the hard, novel piece, don't build it on unverified
    kinematics):
      1. For each external-perimeter move, instead of a single straight-down
         ray-cast, sample the LOCAL mesh patch around the wall path (a small
         neighborhood, not just the one point under the nozzle) to estimate
         a smoothed surface normal -- raw per-point face normals are noisy
         at wall edges/corners in a way a single top-surface ray-cast isn't.
      2. Continuously vary A/B along the wall path rather than the
         point-by-point `prefer_a_near` nudge used above -- this needs an
         actual orientation-trajectory smoother (e.g. minimize total A/B
         angular travel subject to reachability), not just "closest to the
         last point."
      3. Collision-check the swept nozzle/fan-shroud volume against the
         in-process part for every sample, not just the nozzle tip position
         -- a tilted head clears the tip but can still gouge the shroud into
         a wall on the opposite side of a thin feature.
      4. This is also the exact area the Autodesk patent (US10005126B2)
         sits closest to -- get the FTO review before shipping this stage
         commercially, not just before launch.
    """
    raise NotImplementedError("outer-wall nonplanar retargeting: see docstring")
