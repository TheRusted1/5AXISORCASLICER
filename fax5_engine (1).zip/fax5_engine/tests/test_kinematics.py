"""
These tests use MachineConfig.placeholder() — fake numbers, just enough to
exercise the math. They prove the FK/IK pair is *internally consistent*
(IK then FK returns you to where you asked). They do NOT prove the sign
conventions match the real machine. That can only be checked by jogging the
real axes and comparing -- see kinematics.py module docstring.
"""

import numpy as np
import pytest

from fax5.kinematics import (
    forward_kinematics,
    inverse_kinematics,
    UnreachableOrientationError,
)
from fax5.machine_config import MachineConfig


@pytest.fixture
def cfg():
    return MachineConfig.placeholder()


def test_fk_at_zero_pose(cfg):
    pose = forward_kinematics(0, 0, 100, 0, 0, cfg)
    # At A=0,B=0 the nozzle should sit straight below the head reference
    # point by exactly the pivot offset + nozzle offset (both default to
    # "straight down" in the placeholder config).
    expected = np.array([0, 0, 100]) + cfg.tilt_pivot_offset + cfg.nozzle_offset_from_pivot
    assert np.allclose(pose.nozzle_pos_world, expected)
    assert np.allclose(pose.tool_axis_world, [0, 0, -1])


@pytest.mark.parametrize(
    "point,normal",
    [
        ([0, 0, 0], [0, 0, 1]),  # flat top, pointing straight up
        ([10, 5, 2], [0, 0, 1]),
        ([10, 5, 2], [0.3, 0.0, 0.95]),  # gently sloped surface
        ([-8, 12, 5], [0.0, 0.4, 0.9]),
        ([3, -3, 1], [0.2, 0.2, 0.95]),
    ],
)
def test_ik_then_fk_round_trip(cfg, point, normal):
    p = np.array(point, dtype=float)
    n = np.array(normal, dtype=float)
    n = n / np.linalg.norm(n)
    target_axis = -n  # nozzle approaches from outside, aimed inward

    solutions = inverse_kinematics(p, target_axis, cfg)
    assert len(solutions) >= 1, "expected at least one IK solution for a reachable target"

    for x, y, z, a_deg, b_deg in solutions:
        pose = forward_kinematics(x, y, z, a_deg, b_deg, cfg)
        assert np.allclose(pose.nozzle_pos_part, p, atol=1e-6), (
            f"position round-trip failed: wanted {p}, got {pose.nozzle_pos_part}"
        )
        assert np.allclose(pose.tool_axis_part, target_axis, atol=1e-6), (
            f"orientation round-trip failed: wanted {target_axis}, got {pose.tool_axis_part}"
        )


def test_ik_respects_b_limits(cfg):
    # cfg.placeholder() limits B to [-90, 0]. A target that would need a
    # tilt outside that range should still solve via a different A (the
    # bed can spin to bring the geometry into reach) -- only a genuinely
    # vertical-flip target should be unreachable for this single-tilt-axis
    # machine.
    p = np.array([0.0, 0.0, 0.0])
    target_axis = np.array([0.0, 0.0, 1.0])  # nozzle pointing straight up
    with pytest.raises(UnreachableOrientationError):
        inverse_kinematics(p, target_axis, cfg)


def test_trident_250_test_config_round_trips():
    """Smoke test for MachineConfig.voron_trident_250_test() -- rough
    numbers, not measured hardware, but the kinematics must still be
    internally consistent for them."""
    cfg = MachineConfig.voron_trident_250_test()
    p = np.array([60.0, 70.0, 30.0])
    n = np.array([0.15, 0.05, 0.98])
    n = n / np.linalg.norm(n)
    target_axis = -n
    solutions = inverse_kinematics(p, target_axis, cfg)
    assert len(solutions) >= 1
    x, y, z, a_deg, b_deg = solutions[0]
    pose = forward_kinematics(x, y, z, a_deg, b_deg, cfg)
    assert np.allclose(pose.nozzle_pos_part, p, atol=1e-6)
    assert np.allclose(pose.tool_axis_part, target_axis, atol=1e-6)


def test_prefer_a_near_picks_closer_branch(cfg):
    p = np.array([5.0, 0.0, 0.0])
    n = np.array([0.1, 0.0, 0.99])
    n = n / np.linalg.norm(n)
    target_axis = -n
    solutions = inverse_kinematics(p, target_axis, cfg, prefer_a_near=10.0)
    if len(solutions) > 1:
        # first candidate should be the one closest to 10 degrees
        a_first = solutions[0][3]
        a_rest = [s[3] for s in solutions[1:]]
        d_first = min(abs((a_first - 10.0 + 180) % 360 - 180), 360)
        for a in a_rest:
            d_other = min(abs((a - 10.0 + 180) % 360 - 180), 360)
            assert d_first <= d_other
