# fax5_engine

5-axis nonplanar post-processing engine for a rotating-bed / tilting-head
FDM printer (Voron Trident-class CoreXY + Klipper electronics). Sits on top
of an **unmodified** OrcaSlicer install rather than forking it.

## Architecture

```
OrcaSlicer (unmodified, AGPLv3)
    |  headless CLI: `orca-slicer --slice 0 project.3mf`
    v
ordinary 3-axis G-code
    |  fax5.gcode_io.parse()
    v
classified moves  <-- fax5.pipeline.classify_moves() reads Orca's own
    |                  ";TYPE:" comments (Top solid infill, etc.) -- no
    |                  mesh analysis needed for this step
    v
fax5.pipeline.retarget_top_bottom()
    |  ray-cast each top/bottom move against the ORIGINAL mesh (trimesh)
    |  to find the real surface point + normal
    |  -> fax5.kinematics.inverse_kinematics() solves (x,y,z,a,b)
    v
5-axis G-code (A/B words added only on retargeted moves)
    |  fax5.gcode_io.write()
    v
Klipper
```

OrcaSlicer is never patched or linked against -- it's invoked as an
external program and its G-code is read as a file. That's the standard,
accepted way to use AGPL/GPL tools from closed-source software: you're not
distributing a derivative of OrcaSlicer, just calling it. Keep it that way;
if you ever start editing OrcaSlicer's own source, that AGPL boundary
disappears and the whole codebase you touch must be released under AGPLv3.

## Status

| Piece | Status |
|---|---|
| Kinematics (FK + IK, rotating bed + tilting head) | Implemented, round-trip tested (`tests/test_kinematics.py`) |
| G-code parse/write | Implemented, tested (`tests/test_gcode_io.py`) |
| OrcaSlicer headless invocation | Written (`pipeline.orcaslicer_slice`), **not runnable in this dev environment** (no GUI/display here) -- verify the exact CLI flags with `orca-slicer --help` on your machine before trusting the call as written |
| Top/bottom nonplanar retargeting | Implemented, tested end-to-end on a synthetic part (`tests/test_pipeline.py`) |
| Outer-wall nonplanar retargeting | **Not implemented.** Stub with the planned approach in `pipeline.retarget_outer_wall` docstring -- needs continuous orientation-trajectory planning and real collision modeling, build it after the kinematics are verified on hardware |
| Collision detection (nozzle/shroud vs. part) | **Not implemented.** Required before any of this drives a real print |
| Klipper-side motion (A/B as kinematic axes vs. manual_stepper) | Not started -- this is firmware/config work, not in this repo |

## What you need to fill in before any of this is real

Five numbers in `src/fax5/machine_config.py`, measured off the actual
machine (see that file's module docstring for exactly how to measure each):

- `tilt_pivot_offset`
- `tilt_axis_local`
- `nozzle_offset_from_pivot`
- `bed_center_xy`
- `b_axis_limits_deg`

Until then, `MachineConfig.placeholder()` is fake numbers good enough to
exercise the math -- never feed its output to a real printer.

## Running it

```bash
pip install -r requirements.txt
PYTHONPATH=src python3 -m pytest tests/ -v
```

## Known risk

The kinematics math is internally self-consistent (proven by the round-trip
tests) but **not yet validated against real hardware**. Before trusting any
G-code this produces: jog A and B a small known amount on the real machine
with the nozzle backed well away from the bed, and confirm
`forward_kinematics()` predicts the resulting pose. A flipped sign here is a
full-speed nozzle-into-bed crash, not a cosmetic bug.

## Patent note

Outer-wall nonplanar generation for interlayer strength sits close to
US10005126B2 (Autodesk). Get a freedom-to-operate review before
commercializing that specific feature. Not legal advice.
